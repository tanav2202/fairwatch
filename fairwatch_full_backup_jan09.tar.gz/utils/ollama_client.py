
import requests
import logging
from dataclasses import dataclass
from typing import Optional, Dict, Any

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger(__name__)

@dataclass
class GenerationConfig:
    temperature: float = 0.7
    max_tokens: int = 500
    top_p: float = 0.9
    json_mode: bool = False
    def to_options(self): return {"temperature": self.temperature, "num_predict": self.max_tokens, "top_p": self.top_p}

@dataclass
class GenerationResult:
    text: str
    success: bool
    error_message: Optional[str] = None

class OllamaClient:
    def __init__(self, model="llama3.2", base_url="http://127.0.0.1:11434", timeout=300):
        import os
        base_url = os.environ.get('OLLAMA_HOST', base_url)
        self.model = model
        self.generate_url = f"{base_url}/api/generate"
        self.timeout = timeout
        self.session = requests.Session()

    def generate(self, prompt, system_prompt=None, config=None):
        if not config: config = GenerationConfig()
        full_prompt = f"System: {system_prompt}\n\nUser: {prompt}" if system_prompt else prompt
        
        payload = {"model": self.model, "prompt": full_prompt, "stream": False, "options": config.to_options()}
        if config.json_mode: payload["format"] = "json"

        try:
            res = self.session.post(self.generate_url, json=payload, timeout=self.timeout)
            if res.status_code == 200: return GenerationResult(text=res.json().get("response", ""), success=True)
            return GenerationResult(text="", success=False, error_message=f"HTTP {res.status_code}")
        except Exception as e:
            return GenerationResult(text="", success=False, error_message=str(e))
