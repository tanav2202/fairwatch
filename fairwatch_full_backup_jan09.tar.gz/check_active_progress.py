import json
import os
import sys
from datetime import datetime
from pathlib import Path

def check_file(filepath):
    print(f"\nChecking {filepath}...")
    if not os.path.exists(filepath):
        print(f"❌ File not found: {filepath}")
        return None

    try:
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        print("✅ VALID JSON")
        
        metadata = data.get("metadata", {})
        results = data.get("results", [])
        
        completed = len(results)
        total = metadata.get("total_prompts", 5760)
        
        start_str = metadata.get("started_at")
        last_upd_str = metadata.get("last_updated")
        
        print(f"  chains_completed: {completed}/{total}")
        
        if start_str and last_upd_str:
            start_time = datetime.fromisoformat(start_str)
            last_time = datetime.fromisoformat(last_upd_str)
            
            duration = (last_time - start_time).total_seconds()
            
            if completed > 0:
                avg_time = duration / completed
                remaining = total - completed
                eta_seconds = remaining * avg_time
                eta_hours = eta_seconds / 3600
                
                print(f"  avg_time_per_chain: {avg_time:.2f}s")
                print(f"  elapsed_time: {duration/60:.1f}m")
                print(f"  estimated_remaining: {eta_hours:.2f} hours")
                return eta_seconds
        
        return None

    except json.JSONDecodeError as e:
        print(f"❌ INVALID JSON: {e}")
        return None
    except Exception as e:
        print(f"❌ ERROR: {e}")
        return None

files = []
# Find all JSON files in the parallel output directory
import glob
files = glob.glob("outputs_parallel/**/*.json", recursive=True)

if not files:
    print("No output files found yet (workers might still be starting/saving)...")

max_remaining_per_gpu = {} # Track max remaining time per GPU to determine bottleneck
active_workers = 0
max_remaining = 0

print(f"Found {len(files)} active output files.")

total_completed = 0
total_target = 5760 * 3 # 3 orderings * 5760 prompts

for f in files:
    # Estimate remaining time for this specific worker
    remaining = check_file(f)
    
    if remaining is not None:
        active_workers += 1
        
        # Extract GPU/Ordering context from filename/path if possible, 
        # but for now just taking the MAX remaining time across all workers 
        # is the safest conservative estimate for "when will EVERYTHING finish"
        max_remaining = max(max_remaining, remaining)

print("\n" + "="*50)
print("PARALLEL SWARM STATUS")
print("="*50)
print(f"Active Workers Contributing: {active_workers}/24")
if active_workers > 0:
    print(f"Time until ALL runs are complete: {max_remaining/3600:.2f} hours")
    
    from datetime import timedelta
    completion_time = datetime.now() + timedelta(seconds=max_remaining)
    print(f"Expected completion time: {completion_time.strftime('%Y-%m-%d %H:%M:%S')}")
else:
    print("Waiting for first results...")
