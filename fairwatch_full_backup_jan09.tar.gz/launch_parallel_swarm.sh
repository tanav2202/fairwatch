#!/bin/bash

# Configuration
NUM_SHARDS=8
DATA_FILE="data/prompts_simple.csv"

echo "Launching 24 parallel workers..."

# Function to launch workers for a specific GPU and ordering
launch_gpu_workers() {
    local GPU_PORT=$1
    local ORDERING=$2
    local SESSION_PREFIX=$3
    
    echo "Launching workers for $ORDERING on port $GPU_PORT..."
    
    for ((i=0; i<NUM_SHARDS; i++)); do
        SESSION_NAME="${SESSION_PREFIX}_w${i}"
        
        # Kill existing session if any
        tmux kill-session -t $SESSION_NAME 2>/dev/null
        
        # Launch new worker in tmux
        tmux new-session -d -s $SESSION_NAME \
            "export OLLAMA_HOST=http://127.0.0.1:$GPU_PORT; \
             python3 evaluation/run_sequential_chains_incremental.py \
                --llm llama3.2 \
                --prompts $DATA_FILE \
                --ordering $ORDERING \
                --output outputs_parallel \
                --shard-idx $i \
                --total-shards $NUM_SHARDS > logs/${SESSION_PREFIX}_shard${i}.log 2>&1"
                
        echo "  Started worker $i (Shard $i/$NUM_SHARDS)"
    done
}

mkdir -p logs

# GPU 0: Ordering 1
launch_gpu_workers 11434 "regulatory_risk_data_consumer" "gpu0"

# GPU 1: Ordering 2
launch_gpu_workers 11435 "risk_data_regulatory_consumer" "gpu1"

# GPU 2: Ordering 3
launch_gpu_workers 11436 "risk_data_consumer_regulatory" "gpu2"

echo "✅ All 24 workers launched!"
echo "Monitor progress with: tail -f logs/*.log"
