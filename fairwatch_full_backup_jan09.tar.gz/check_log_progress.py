import glob
import re

log_files = glob.glob("logs/*.log")
total_chains = 0
total_target = 3 * 5760  # 3 orderings * 5760 prompts
worker_counts = []

print(f"Checking {len(log_files)} log files...")

for log_file in log_files:
    last_chain = 0
    try:
        # Read the file and find the last "Running chain X/Y" line
        with open(log_file, 'r') as f:
            for line in f:
                if "Running chain" in line and "/" in line:
                    # Extract the number before the /
                    # Example: Running chain 65/720 (Shard 3)
                    match = re.search(r"Running chain (\d+)/(\d+)", line)
                    if match:
                        last_chain = int(match.group(1)) - 1 # Current one is 'Running', so completed is -1
    except Exception as e:
        print(f"Error reading {log_file}: {e}")
    
    # If last_chain is < 0 (i.e. currently running chain 1), set to 0
    if last_chain < 0: last_chain = 0
    
    worker_counts.append(last_chain)
    total_chains += last_chain

print(f"\nTotal Chains Completed (from logs): {total_chains} / {total_target}")
print(f"Progress: {total_chains / total_target * 100:.2f}%")
print(f"Average per worker: {total_chains / len(log_files):.1f} chains")
